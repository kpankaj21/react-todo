import React, { useEffect, useState } from "react";
import "./App.css";
import Kp from "./kp.png";

// const getLocalItems = () => {
//   let list = localStorage.getItem("lists");
//   if (list) {
//     return JSON.parse(localStorage.getItem("lists"));
//   } else {
//     return [];
//   }
// };

function Registration() {
  const [fname, setfname] = useState("");
  const [userData, setUserData] = useState([]);
  const [isUpdate, setIsUpdate] = useState(true);
  const [isEditItem, setIsEditItem] = useState(null);
  // const [isComplete, setIsComplete] = useState([]);
  // const [isActive, setIsActive] = useState([]);
  const [displayList, setdisplayList] = useState([]);
  const [tab, setTab] = useState("all");

  useEffect(() => {
    let list = localStorage.getItem("lists");
    if (list) {
      setUserData(JSON.parse(localStorage.getItem("lists")));
      setdisplayList(JSON.parse(localStorage.getItem("lists")));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("lists", JSON.stringify(userData));
    setdisplayList(userData);
    onFilter(tab);
  }, [userData]);

  const addClick = (_e) => {
    if (fname && !isUpdate) {
      setUserData(
        userData.map((item) => {
          if (item.id === isEditItem) {
            return { ...item, Name: fname };
          }
          return item;
        })
      );
      setfname("");
      setIsUpdate(true);
    } else if (fname !== "") {
      setUserData([
        ...userData,
        {
          id: Math.random().toString().substr(9, 4),
          Name: fname,
          status: false,
        },
      ]);
      setfname("");
    } else {
      alert("Plzz Enter Value");
    }
  };

  const editClick = (id) => {
    console.log("idddd", id);
    const editItem = userData.find((item) => item.id === id);

    setfname(editItem.Name);
    setIsUpdate(false);
    setIsEditItem(id);
  };
  const deleteClick = (id) => {
    const deleteItem = userData.filter((item) => item.id !== id);
    setUserData(deleteItem);
  };

  const checkHandler = (id) => {
    console.log("check idddd", id);

    let data = userData.map((item) => {
      if (item.id === id) {
        return { ...item, status: !item.status };
      }
      return item;
    });
    setUserData(data);
    localStorage.setItem("lists", JSON.stringify(data));

    // let data =userData.map((item) => {
    //   if(item.id ===id){
    //     return {...item,status:!item.status }
    //   }
    //   return item
    // })
    // setUserData(data)
    // setIsChecked(true)
  };

  const onFilter = (key) => {
    setTab(key);
    console.log("userData", userData);
    const dummyData = userData;

    const fiterIten = dummyData.filter((item) => {
      switch (key) {
        case "complete":
          return item.status;

        case "active":
          return !item.status;

        default:
          return true;
      }
    });
    setdisplayList(fiterIten);
  };

  // const allClick = () => {

  // };

  // const completeClick = (e) => {
  //   var completeData = userData.filter((item) => item.status === true);
  //   setIsComplete(completeData);
  //   console.log("isCompelete",isComplete);

  //    //localStorage.setItem("lists", JSON.stringify(completeData));

  // };

  // const activeClick = (e) => {
  //    var activeData = userData.filter((item) => item.status === false);
  //    setIsActive(activeData);
  //    console.log("is Active",isActive);

  //   //localStorage.setItem("lists", JSON.stringify(activeData));
  // };

  const removeAll = (e) => {
    setUserData([]);
  };

  /// console.log("storee", userData);

  return (
    <>
      <div className="imgid">
        <img src={Kp} alt="todoimg" width="200px" />
      </div>
      <div className="inputid">
        <br />
        <br />
        <input
          placeholder="input value..."
          type="text"
          value={fname}
          onChange={(e) => {
            setfname(e.target.value);
          }}
        />

        {isUpdate ? (
          <button className="btn btn-primary" onClick={(e) => addClick(e)}>
            Add{" "}
          </button>
        ) : (
          <button className="btn btn-success" onClick={(e) => addClick(e)}>
            Update{" "}
          </button>
        )}
      </div>
      <div className="userName">
        {displayList &&
          displayList.length > 0 &&
          displayList.map((item) => {
            return (
              <div key={item.id}>
                <input
                  type="checkbox"
                  className="m-4"
                  value={item.Name}
                  checked={item.status ? true : false}
                  onChange={() => checkHandler(item.id)}
                />
                <span
                  style={
                    item.status ? { textDecoration: "line-through" } : null
                  }
                >
                  {item.Name}
                </span>
                <button
                  className="btn btn-warning"
                  onClick={() => editClick(item.id)}
                >
                  Edit
                </button>{" "}
                <button
                  className="btn btn-danger"
                  onClick={() => deleteClick(item.id)}
                >
                  Delete
                </button>
                <br />
              </div>
            );
          })}
        <div className="active">
          <button
            className="btn btn-outline-success"
            onClick={(e) => onFilter("all")}
          >
            All
          </button>
          <button
            className="btn btn-outline-secondary"
            onClick={(e) => onFilter("complete")}
          >
            Complete
          </button>
          <button
            className="btn btn-outline-info"
            onClick={(e) => onFilter("active")}
          >
            Active
          </button>

          <button
            className="btn btn-outline-danger"
            onClick={(e) => removeAll(e)}
          >
            RemoveAll
          </button>
        </div>
      </div>
    </>
  );
}

export default Registration;
