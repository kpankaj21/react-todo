import React from 'react';
 import Registration from './Registration';
 import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
 

  function App()  {
  return (

    <>
    <Registration />
  </>
    )
};
export default App;