import React from "react";
import ReactDOM from "react-dom";
import "./index.css";
import App from "./App";
import reportWebVitals from "./reportWebVitals";
 
  
// import "../node_modules/bootstrap/dist/css/bootstrap.css"

ReactDOM.render(<App />, document.getElementById("root"));
//ReactDOM.render(<Registration />, document.getElementById("root"));
 
reportWebVitals();
